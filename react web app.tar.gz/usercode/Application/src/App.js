import './index.css';

function App() {
  return (
    <div className="App">
      <h1> Hello from <span> Educative! </span> </h1>
    </div>
  );
}

export default App;
